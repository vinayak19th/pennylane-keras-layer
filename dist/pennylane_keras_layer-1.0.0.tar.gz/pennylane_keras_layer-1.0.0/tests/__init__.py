"""Test suite initialization for pennylane-keras-layer package."""

# Test configuration and shared fixtures can be added here
