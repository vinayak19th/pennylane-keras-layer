"""Setup script for pennylane-keras-layer package."""

from setuptools import setup

# All configuration is in pyproject.toml
# This file is kept for backward compatibility and editable installs
setup()
